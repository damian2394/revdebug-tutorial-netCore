﻿ 
$(".help").click(function () {
    $(".overlay").show();
});